<?php
    include("header.php");
?>

<h1>Services</h1>

<?php
    include("footer.php");
?>