
        <section id="portfolio">
			<div class="container portfolio_area text-center">                
                
                <!-- Portfolio grid -->
				<h2>Swimming Pool</h2>	
                <div class="grid">
					<!--bramha-->
                    <div class="grid-sizer"></div>
                    <div class="grid-item grid-item bramha major">
                        <img alt="" src="images/bramha.jpg" >
                        <div class="portfolio_hover_area">
                            <a class="fancybox" href="images/bramha.jpg" data-fancybox-group="gallery" title="Bramhacorp F Residences"><span class="fa fa-search"></span></a>
                            
                        </div>  
                    </div>
					<div class="grid-sizer"></div>
                    <div class="grid-item grid-item bramha">
                        <img alt="" src="images/bramha2.jpg" >
                        <div class="portfolio_hover_area">
                            <a class="fancybox" href="images/bramha2.jpg" data-fancybox-group="gallery" title="Bramhacorp F Residences"><span class="fa fa-search"></span></a>
                            
                        </div>  
                    </div>
					<div class="grid-sizer"></div>
                    <div class="grid-item grid-item bramha">
                        <img alt="" src="images/bramha3.jpg" >
                        <div class="portfolio_hover_area">
                            <a class="fancybox" href="images/bramha3.jpg" data-fancybox-group="gallery" title="Bramhacorp F Residences"><span class="fa fa-search"></span></a>
                            
                        </div>  
                    </div>
					<div class="grid-item grid-item bramha">
                        <img alt="" src="images/bramha4.jpg" >
                        <div class="portfolio_hover_area">
                            <a class="fancybox" href="images/bramha4.jpg" data-fancybox-group="gallery" title="Bramhacorp F Residences"><span class="fa fa-search"></span></a>
                            
                        </div>  
                    </div>
					<!--bramha-->
			    </div><!-- Portfolio grid end -->
				
				<!-- Portfolio grid -->
				<h2>Service 2</h2>	
                <div class="grid">
					<!--bramha-->
                    <div class="grid-sizer"></div>
                    <div class="grid-item grid-item bramha major">
                        <img alt="" src="images/bramha.jpg" >
                        <div class="portfolio_hover_area">
                            <a class="fancybox" href="images/bramha.jpg" data-fancybox-group="gallery" title="Bramhacorp F Residences"><span class="fa fa-search"></span></a>
                            
                        </div>  
                    </div>
					<div class="grid-sizer"></div>
                    <div class="grid-item grid-item bramha">
                        <img alt="" src="images/bramha2.jpg" >
                        <div class="portfolio_hover_area">
                            <a class="fancybox" href="images/bramha2.jpg" data-fancybox-group="gallery" title="Bramhacorp F Residences"><span class="fa fa-search"></span></a>
                            
                        </div>  
                    </div>
					<div class="grid-sizer"></div>
                    <div class="grid-item grid-item bramha">
                        <img alt="" src="images/bramha3.jpg" >
                        <div class="portfolio_hover_area">
                            <a class="fancybox" href="images/bramha3.jpg" data-fancybox-group="gallery" title="Bramhacorp F Residences"><span class="fa fa-search"></span></a>
                            
                        </div>  
                    </div>
					<div class="grid-item grid-item bramha">
                        <img alt="" src="images/bramha4.jpg" >
                        <div class="portfolio_hover_area">
                            <a class="fancybox" href="images/bramha4.jpg" data-fancybox-group="gallery" title="Bramhacorp F Residences"><span class="fa fa-search"></span></a>
                            
                        </div>  
                    </div>
					<!--bramha-->
			    </div><!-- Portfolio grid end -->
				
				<!-- Portfolio grid -->
				<h2>Service3</h2>	
                <div class="grid">
					<!--bramha-->
                    <div class="grid-sizer"></div>
                    <div class="grid-item grid-item bramha major">
                        <img alt="" src="images/bramha.jpg" >
                        <div class="portfolio_hover_area">
                            <a class="fancybox" href="images/bramha.jpg" data-fancybox-group="gallery" title="Bramhacorp F Residences"><span class="fa fa-search"></span></a>
                            
                        </div>  
                    </div>
					<div class="grid-sizer"></div>
                    <div class="grid-item grid-item bramha">
                        <img alt="" src="images/bramha2.jpg" >
                        <div class="portfolio_hover_area">
                            <a class="fancybox" href="images/bramha2.jpg" data-fancybox-group="gallery" title="Bramhacorp F Residences"><span class="fa fa-search"></span></a>
                            
                        </div>  
                    </div>
					<div class="grid-sizer"></div>
                    <div class="grid-item grid-item bramha">
                        <img alt="" src="images/bramha3.jpg" >
                        <div class="portfolio_hover_area">
                            <a class="fancybox" href="images/bramha3.jpg" data-fancybox-group="gallery" title="Bramhacorp F Residences"><span class="fa fa-search"></span></a>
                            
                        </div>  
                    </div>
					<div class="grid-item grid-item bramha">
                        <img alt="" src="images/bramha4.jpg" >
                        <div class="portfolio_hover_area">
                            <a class="fancybox" href="images/bramha4.jpg" data-fancybox-group="gallery" title="Bramhacorp F Residences"><span class="fa fa-search"></span></a>
                            
                        </div>  
                    </div>
					<!--bramha-->
			    </div><!-- Portfolio grid end -->
				
				<!-- Portfolio grid -->
				<h2>Service4</h2>	
                <div class="grid">
					<!--bramha-->
                    <div class="grid-sizer"></div>
                    <div class="grid-item grid-item bramha major">
                        <img alt="" src="images/bramha.jpg" >
                        <div class="portfolio_hover_area">
                            <a class="fancybox" href="images/bramha.jpg" data-fancybox-group="gallery" title="Bramhacorp F Residences"><span class="fa fa-search"></span></a>
                            
                        </div>  
                    </div>
					<div class="grid-sizer"></div>
                    <div class="grid-item grid-item bramha">
                        <img alt="" src="images/bramha2.jpg" >
                        <div class="portfolio_hover_area">
                            <a class="fancybox" href="images/bramha2.jpg" data-fancybox-group="gallery" title="Bramhacorp F Residences"><span class="fa fa-search"></span></a>
                            
                        </div>  
                    </div>
					<div class="grid-sizer"></div>
                    <div class="grid-item grid-item bramha">
                        <img alt="" src="images/bramha3.jpg" >
                        <div class="portfolio_hover_area">
                            <a class="fancybox" href="images/bramha3.jpg" data-fancybox-group="gallery" title="Bramhacorp F Residences"><span class="fa fa-search"></span></a>
                            
                        </div>  
                    </div>
					<div class="grid-item grid-item bramha">
                        <img alt="" src="images/bramha4.jpg" >
                        <div class="portfolio_hover_area">
                            <a class="fancybox" href="images/bramha4.jpg" data-fancybox-group="gallery" title="Bramhacorp F Residences"><span class="fa fa-search"></span></a>
                            
                        </div>  
                    </div>
					<!--bramha-->
			    </div><!-- Portfolio grid end -->
				
				<!-- Portfolio grid -->
				<h2>Service5</h2>	
                <div class="grid">
					<!--bramha-->
                    <div class="grid-sizer"></div>
                    <div class="grid-item grid-item bramha major">
                        <img alt="" src="images/bramha.jpg" >
                        <div class="portfolio_hover_area">
                            <a class="fancybox" href="images/bramha.jpg" data-fancybox-group="gallery" title="Bramhacorp F Residences"><span class="fa fa-search"></span></a>
                            
                        </div>  
                    </div>
					<div class="grid-sizer"></div>
                    <div class="grid-item grid-item bramha">
                        <img alt="" src="images/bramha2.jpg" >
                        <div class="portfolio_hover_area">
                            <a class="fancybox" href="images/bramha2.jpg" data-fancybox-group="gallery" title="Bramhacorp F Residences"><span class="fa fa-search"></span></a>
                            
                        </div>  
                    </div>
					<div class="grid-sizer"></div>
                    <div class="grid-item grid-item bramha">
                        <img alt="" src="images/bramha3.jpg" >
                        <div class="portfolio_hover_area">
                            <a class="fancybox" href="images/bramha3.jpg" data-fancybox-group="gallery" title="Bramhacorp F Residences"><span class="fa fa-search"></span></a>
                            
                        </div>  
                    </div>
					<div class="grid-item grid-item bramha">
                        <img alt="" src="images/bramha4.jpg" >
                        <div class="portfolio_hover_area">
                            <a class="fancybox" href="images/bramha4.jpg" data-fancybox-group="gallery" title="Bramhacorp F Residences"><span class="fa fa-search"></span></a>
                            
                        </div>  
                    </div>
					<!--bramha-->
			    </div><!-- Portfolio grid end -->
			</div>
			
		</section>	