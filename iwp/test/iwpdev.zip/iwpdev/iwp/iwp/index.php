<?php
    include("php/header.php");
?>

<?php
    include("php/home.php");
?>

<?php
    include("php/footer.php");
?>